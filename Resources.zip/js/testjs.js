﻿$(function () {
    console.log("ready!");
    alert("ready!");
});